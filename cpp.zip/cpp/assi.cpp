// #include<iostream>
// #include<string.h>
// using namespace std;

// int main(){
//     char ch[10];
//     cout<<"Get the string"<<endl;
//     cin>>ch;
//     int x = strlen(ch);
//     cout<<"Number of characters "<<x<<endl;
//     char ch1[10];
//     strcpy(ch1,gets(ch));

//     cout<<ch1<<endl;

//     int y=strlen(ch1);

//     cout<<"Number of characters"<<x+y<<endl;

//     int count = 0; // this is for space count

//     int count1=0;  // this is for vowels count
//     // while(*ch1 !='\0'){
//     //     if(*ch1==' '){
//     //         count++;
//     //     }
//     //     *ch1++;

//     // }
//     // cout<<count;

//     for (int i =0; i<=y; i++){
//         if(ch1[i]==' '){
//             count++;
//         }
//     }
//     cout<<"number of space in string "<<count<<endl;

//     for (int i = 0; i <=x ; i++)
//     {
        
//         if (ch[i]=='a'||ch[i]=='e'||ch[i]=='i'||ch[i]=='o'||ch[i]=='u'||ch[i]=='A'||ch[i]=='E'||ch[i]=='I'||ch[i]=='O'||ch[i]=='U')
//         {
//             count1++;
//         }
//     }

//       for (int i = 0; i <=y ; i++)
//     {
        
//         if (ch1[i]=='a'||ch1[i]=='e'||ch1[i]=='i'||ch1[i]=='o'||ch1[i]=='u'||ch1[i]=='A'||ch1[i]=='E'||ch1[i]=='I'||ch1[i]=='O'||ch1[i]=='U')
//         {
//             count1++;
//         }
//     }
    
//     cout<<"number of vowels in string "<<count1<<endl;


//     cout<<"number of words in string "<<count+1<<endl;


//     // add the remaning character to the ch without space
//     char withoutspace[y];
//     int j=0;
//     for(int i=0;i<=y;i++){
//         if(ch1[i]!=' '){
//           withoutspace[j]=ch1[i];
//           j++;
//         }
      
//     }
//     fo
//     char s[10]=ch;
//     // strcat(ch,withoutspace);
    
    
//     cout<<"The string without spaces is:"<<withoutspace<<endl;







//     // cout<<puts(ch);


// }