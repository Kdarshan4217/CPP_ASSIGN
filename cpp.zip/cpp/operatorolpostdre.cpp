#include<iostream>
using namespace std;

class complex{
    int real ,img;

    public:
    complex(int,int);

complex operator--(int);
void display();



};

complex :: complex(int real, int img) {
    this->real = real;
    this->img = img;
}

complex complex :: operator--(int){
    complex temp =(*this);
    temp.img=this->img--;
    temp.real= this->real--;
    return temp;
}

 void complex ::  display(){
 cout<<real<<"+"<<img<<"i"<<endl;
 }

int main(){
    complex c1(10,20);

    complex c2 = c1--; 

    c1.display();
    c2.display();

    return 0;
 
}
