#include<iostream>
#include<string.h>
using namespace std;
class wagemp{
     int sal=2000000;
     protected:
     string name="Rahul";
    //  char surname[5];
    //  surname="Abcd";

    


   friend void getData(wagemp&);
     
};

void getData(wagemp& w1){
    cout<<"The salary of emp "<<w1.sal<<endl;
    cout<<"The name of emp "<<w1.name<<endl;
    
}

int main(){
wagemp we;
getData(we);



}