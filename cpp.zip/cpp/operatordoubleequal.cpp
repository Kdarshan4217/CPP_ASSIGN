#include<iostream>
#include<string.h>
using namespace std;

class book{
    int price;
    string name;
    public:
    book(int price,string name){
       this->price=price;
       this->name=name;
    }
    bool operator==(book& b){
        if(this->price==b.price && this->name==b.name){
            return true;
        }
        return false;
    }
};
int main(){
    book b1(200,"ABCD");
    book b2(300,"gfsh");
    b1==b2;
    if(b1==b2){
        cout<<"is equal:"<<endl;
    }else{
        cout<<"not equal"<<endl;
    }
}