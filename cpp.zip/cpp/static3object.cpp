#include <iostream>
using namespace std;
 
class Player
{
private:
    int id;
    static int next_id; // 2, 3 ,4
public:
    int getID() { return id; }
    Player()  {  id = next_id++; }
    // int getNetxId(){ return next_id;}

};
int Player::next_id = 1;
 
int main()
{
  Player p1; //  1 ==> after ++ == 2
  Player p2; //  2 ==> after ++ == 3
  Player p3; //  3 ==> after ++ == 4
   Player p4;

  cout << p1.getID() << " ";
  cout << p2.getID() << " ";
  cout << p3.getID()<<" ";
   cout << p4.getID()<<" ";
//    cout << p4.getNetxId();

  return 0;
}