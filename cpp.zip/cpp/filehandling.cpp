#include<iostream>
#include<fstream>
using namespace std;
int main(){
    ofstream file("file1.txt");
    if(!file){
        cout<<"Error:Unable to open the file"<<endl;

    }
    while (!file.eof())
    {
     getline(file,line);
     cout<<line<<endl;
    }
    
    file.close();
}

