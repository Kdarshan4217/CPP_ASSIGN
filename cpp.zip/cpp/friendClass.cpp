#include<iostream>
using namespace std;

int main (){

    class Swift{
        
        int wheel = 4 ;
        protected :
        int petrolTank = 30;


        friend class omni;
    };

    class omni{
        public :
      void Totake(Swift& s1){
        cout<<s1.wheel <<endl; 
        cout<< s1.petrolTank<<endl;
      }
       
    };


    Swift s;
    omni o;
    o.Totake(s);
}