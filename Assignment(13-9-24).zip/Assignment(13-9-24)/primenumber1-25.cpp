#include<iostream>
#include<cmath>
using namespace std;

int main(){
    int count=1;
    int num=3;
    while(count<26){
        
    
        if(num%2==0){
           
           count++;
        }
        num++;
    }
    cout<<"coutn"<<count<<endl;
}