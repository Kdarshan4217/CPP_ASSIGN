#include<iostream>
#include<string.h>
using namespace std;
class wagemp;
class emp{
    public:
   void getData(wagemp&);
};
class wagemp{
     int sal=2000000;
     protected:
     string name="Rahul";
    //  char surname[5];
    //  surname="Abcd";
   friend void emp::getData(wagemp&);
     
};

void emp::getData(wagemp& w1)
{
    cout<<"The salary of emp "<<w1.sal<<endl;
    cout<<"The name of emp "<<w1.name<<endl;
    
}

int main(){
wagemp we;
emp e;
e.getData(we);

}