#include<iostream>
#include<string.h>
using namespace std;

class basket{
        int length;
        char* fruits;

        public:
        basket(char*);
        
       basket& operator=(basket& b);

       void display(){
        cout<<fruits<<endl;
       };


};
    basket& basket :: operator=(basket& b)
       {
        length = b.length;
        delete[] fruits;
        fruits = new char[length+1];
        strcpy(fruits,b.fruits);
        return (*this);
       }

       
    basket::basket(char* str)
       {
        length=strlen(str);
        fruits=new char[length+1];
        strcpy(fruits,str);
        }


int main()
{
    basket b1("apple");
    basket b2("mango");


    b1.display();
    b2.display();
    b2=b1;
    b1.display();
    b2.display();
    
}